# 20202GRPEDC01C1M1P1
Projeto Grande

# Nome Do Projeto
Caminhos da Aldeia App
 
# Integrantes
Leandro Amorim e Rafael Santiago

# Assunto 
Aplicativo para gestão de contas a pagar

# Cenário
Condôminos acessam o aplicativo e postam as contas que tiverem pago. O app organiza as contas conforme as datas, retornando o valor a ser pago por cada condômino.